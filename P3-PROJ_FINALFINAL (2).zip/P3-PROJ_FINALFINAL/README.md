# Projeto de P3 (React + Node + MySQL)

## Estrutura

- 'frontend/' - App React
- 'backend/' - API Node.js + Express + Sequelize
- 'docker-compose.yml' - Containers para backend, frontend e MySQL

## Como correr o projeto

Replicar o repositório:

```bash
git clone <repo_url>
cd projeto